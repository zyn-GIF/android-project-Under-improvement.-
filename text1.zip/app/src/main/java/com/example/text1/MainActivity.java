package com.example.text1;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    // 标记：仅插入一次测试数据（避免每次启动重复插）
    private static boolean isTestDataInserted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        // ========== 新增：给已存在的用户aa插入文件数据 ==========
//        if (!isTestDataInserted) {
//            insertTestFileForExistUser("aa"); // 传入已存在的用户名aa
//            isTestDataInserted = true;
//        }

        // ========== 原有：3秒跳转到登录页 ==========
        Handler myhandle = new Handler();
        myhandle.postDelayed(() -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }, 3000);
    }


    private void insertTestFileForExistUser(String username) {
        // 1. 初始化数据库帮助类
        DataBase dbHelper = new DataBase(this);

        // 3. 插入文件数据（关联传入的用户名aa）
        String fileName = "aa的测试文件3.txt";
        String fileContent = "这是给已存在用户aa插入的测试文件3内容";
        // 获取当前时间作为创建时间
        String createTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        long fileId = dbHelper.addFile(username, fileName, fileContent, createTime);
        // 打印日志/提示，确认插入结果
        if (fileId != -1) {
            Log.d("TestInsert", "✅ 给用户" + username + "插入文件成功，文件ID：" + fileId);
            Toast.makeText(this, "给用户" + username + "插入文件成功", Toast.LENGTH_SHORT).show();
        } else {
            Log.e("TestInsert", "❌ 给用户" + username + "插入文件失败");
            Toast.makeText(this, "给用户" + username + "插入文件失败", Toast.LENGTH_SHORT).show();
        }
    }
}