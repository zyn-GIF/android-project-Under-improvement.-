package com.example.text1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Button cmt_btn=findViewById(R.id.submit_button);
        cmt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取输入的账号密码、手机号
                EditText usernameInput=findViewById(R.id.username_edit_text);
                EditText passwdInput=findViewById(R.id.password_edit_text);
                EditText telInput=findViewById(R.id.usertel_edit_text);
                String user_name=usernameInput.getText().toString().trim();
                String passwd=passwdInput.getText().toString().trim();
               String user_tel=telInput.getText().toString().trim();
               if(user_name!=null&&passwd!=null&&user_tel!=null){
                if(passwd.length()>=6){
                    DataBase db=new DataBase(RegisterActivity.this);
                    User user=new User(user_name,passwd,user_tel);
                    long result = db.addUser(user);
                    if(result<0){
                        Toast.makeText(RegisterActivity.this,"注册失败",Toast.LENGTH_SHORT).show();
                    }
                    Toast.makeText(RegisterActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(RegisterActivity.this,KernelActivity.class);
                    intent.putExtra("username",user_name);
                    startActivity(intent);
                }else{
                    Toast.makeText(RegisterActivity.this,"密码不能少于6位",Toast.LENGTH_SHORT).show();
                }
               }else{
                   Toast.makeText(RegisterActivity.this,"账号或密码或手机号不能为空",Toast.LENGTH_SHORT).show();
               }
            }
        });
    }
}
