package com.example.text1;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class KernelActivity extends AppCompatActivity {

    private RecyclerView recyclerViewFiles;
    private FileListAdapter fileAdapter;
    private List<FileInfo> fileList;
    private String currentUsername; // 当前登录的用户名

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kernel);

        // 1. 获取从登录页传递过来的用户名
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");
        // 显示当前登录用户名
        TextView tv = findViewById(R.id.kernel_username);
        tv.setText(currentUsername);

        // 2. 底部导航点击事件（原有逻辑保留）
        findViewById(R.id.textView_mine).setOnClickListener(v -> {
            startActivity(new Intent(KernelActivity.this, MineActivity.class));
        });
        findViewById(R.id.textView_file).setOnClickListener(v -> {
            startActivity(new Intent(KernelActivity.this, UploadFileActivity.class));
        });

        // 3. 初始化RecyclerView
        recyclerViewFiles = findViewById(R.id.recycler_view);
        recyclerViewFiles.setLayoutManager(new LinearLayoutManager(this));

        // 4. 从数据库查询当前用户的真实文件数据（替换假数据）
        fileList = new ArrayList<>();
        DataBase dbHelper = new DataBase(this);
        fileList = dbHelper.getFilesByUsername(currentUsername); // 查询真实数据

        // 5. 初始化Adapter并设置给RecyclerView
        fileAdapter = new FileListAdapter(this, fileList);
        recyclerViewFiles.setAdapter(fileAdapter);

        // 可选：如果没有数据，提示用户
        if (fileList.isEmpty()) {
            Toast.makeText(this, "暂无文件数据", Toast.LENGTH_SHORT).show();
        }
    }

    // ==========  RecyclerView适配器（必须实现，展示文件列表） ==========
    public static class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.FileViewHolder> {
        private Context context;
        private List<FileInfo> fileList;

        // 构造方法
        public FileListAdapter(Context context, List<FileInfo> fileList) {
            this.context = context;
            this.fileList = fileList;
        }

        // 创建ViewHolder（加载文件项布局）
        @NonNull
        @Override
        public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // 加载文件列表项的布局（需自己创建item_file.xml，见下方说明）
            View itemView = LayoutInflater.from(context).inflate(R.layout.item_file, parent, false);
            return new FileViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
            // 防越界
            if (fileList == null || position >= fileList.size()) {
                return;
            }
            FileInfo fileInfo = fileList.get(position);

            // 设置文件名
            if (holder.tvFileName != null) {
                holder.tvFileName.setText(fileInfo.getFileName() == null ? "未知文件" : fileInfo.getFileName());
            }

            // 拼接并设置用户名+时间
            if (holder.tvFileDetails != null) {
                String username = fileInfo.getUsername() == null ? "未知用户" : fileInfo.getUsername();
                String createTime = fileInfo.getCreateTime() == null ? "未知时间" : fileInfo.getCreateTime();
                holder.tvFileDetails.setText(username + " | " + createTime);
            }

            // 设置图标
            if (holder.ivFileIcon != null) {
                holder.ivFileIcon.setImageResource(R.drawable.image16);
            }

            // ========== 核心新增：文件项点击事件 ==========
            holder.itemView.setOnClickListener(v -> {
                // 跳转到文件内容页，并传递文件所有数据
                Intent intent = new Intent(context, FileContentActivity.class);
                intent.putExtra("fileName", fileInfo.getFileName());
                intent.putExtra("username", fileInfo.getUsername());
                intent.putExtra("createTime", fileInfo.getCreateTime());
                intent.putExtra("fileContent", fileInfo.getFileContent()); // 传递文件内容
                context.startActivity(intent);
            });
        }

        // 获取列表长度
        @Override
        public int getItemCount() {
            return fileList.size();
        }

        // ViewHolder类（对应item_file.xml的控件）
        public static class FileViewHolder extends RecyclerView.ViewHolder {
            TextView tvFileName;       // 文件名（对应tv_file_name）
            TextView tvFileDetails;    // 合并的用户名+时间（对应tv_file_details）
            ImageView ivFileIcon;      // 文件图标（对应file_icon）

            public FileViewHolder(@NonNull View itemView) {
                super(itemView);
                // 严格匹配布局中的ID，删除多余的tvFileUser/tvCreateTime
                tvFileName = itemView.findViewById(R.id.tv_file_name);
                tvFileDetails = itemView.findViewById(R.id.tv_file_details); // 绑定合并的控件
                ivFileIcon = itemView.findViewById(R.id.file_icon); // 图标ID匹配布局
            }
        }

    }
}