package com.example.text1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.text1.FileInfo;

import java.util.List;

public class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.FileViewHolder> {

    private List<FileInfo> fileList;
    private Context context;

    // 构造函数，传入上下文和数据列表
    public FileListAdapter(Context context, List<FileInfo> fileList) {
        this.context = context;
        this.fileList = fileList;
    }

    // 创建 ViewHolder（加载 item 布局并实例化控件）
    @NonNull
    @Override
    public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载 item_file.xml 布局
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.item_file, parent, false);
        return new FileViewHolder(itemView);
    }

    // 绑定数据到 ViewHolder（将 FileModel 的数据设置到 item 控件上）
    @Override
    public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
        FileInfo currentFile = fileList.get(position);



        // 设置文件名
        holder.tvFileName.setText(currentFile.getFileName());

        // 设置所属人和修改时间（拼接成一行）
        String details = currentFile.getOwner() + " | " + currentFile.getModifyTime();
        holder.tvFileDetails.setText(details);
    }

    // 返回数据总数
    @Override
    public int getItemCount() {
        return fileList.size();
    }

    // ViewHolder 内部类，用于缓存 item 布局中的控件
    public static class FileViewHolder extends RecyclerView.ViewHolder {

        TextView tvFileName;
        TextView tvFileDetails;

        public FileViewHolder(@NonNull View itemView) {
            super(itemView);
            // 绑定 item_file.xml 中的控件 ID

            tvFileName = itemView.findViewById(R.id.tv_file_name);
            tvFileDetails = itemView.findViewById(R.id.tv_file_details);
        }
    }
}