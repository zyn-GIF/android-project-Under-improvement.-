package com.example.text1;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBase extends SQLiteOpenHelper {
    // 数据库名称
    private static final String DATABASE_NAME = "UserDatabase.db";
    // 数据库版本
    private static final int DATABASE_VERSION = 1;

    // 用户表名称
    public static final String TABLE_USERS = "users";

    // 用户表列名
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_PHONE = "phone";
    //-----------------
    public static final String TABLE_FILES = "files"; // 文件表名称
    // 文件表列名
    public static final String COLUMN_FILE_ID = "file_id"; // 文件唯一ID（主键自增）
    public static final String COLUMN_FILE_USERNAME = "username"; // 关联用户表的用户名（外键）
    public static final String COLUMN_FILE_NAME = "file_name"; // 文件名
    public static final String COLUMN_FILE_CONTENT = "file_content"; // 文件内容
    public static final String COLUMN_FILE_CREATE_TIME = "create_time"; // 文件创建时间

    // 文件表建表 SQL（关联用户表 username，确保文件归属正确）
    private static final String CREATE_TABLE_FILES = "CREATE TABLE " + TABLE_FILES + " ("
            + COLUMN_FILE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_FILE_USERNAME + " TEXT NOT NULL, " // 关联用户表的 username
            + COLUMN_FILE_NAME + " TEXT NOT NULL, " // 文件名非空
            + COLUMN_FILE_CONTENT + " TEXT, " // 文件内容（可空）
            + COLUMN_FILE_CREATE_TIME + " TEXT NOT NULL" // 创建时间非空
            + ");";

    // 创建用户表的 SQL 语句
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " // UNIQUE 确保用户名不重复
            + COLUMN_PASSWORD + " TEXT NOT NULL, "
            + COLUMN_PHONE + " TEXT);";
    public DataBase(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_FILES);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS TABLE_USERS");

        onCreate(db);
    }
    public long addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_USERNAME, user.getUsername());
        values.put(COLUMN_PASSWORD, user.getPassword());
        values.put(COLUMN_PHONE, user.getPhone());

        // 插入数据，返回新行的ID
        long id = db.insert(TABLE_USERS, null, values);
        db.close(); // 关闭数据库连接
        return id;
    }
    public User getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID, COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_PHONE},
                COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null, null);

        User user = null;
        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME)));
            user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD)));
            user.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)));
        }

        cursor.close();
        db.close();
        return user;
    }
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);

        boolean exists = cursor.getCount() > 0;

        cursor.close();
        db.close();
        return exists;
    }
    public long addFile(String username, String fileName, String fileContent, String createTime) {
        // 获取可写数据库
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // 填充文件表字段
        values.put(COLUMN_FILE_USERNAME, username);   // 关联的用户名（aa）
        values.put(COLUMN_FILE_NAME, fileName);       // 文件名
        values.put(COLUMN_FILE_CONTENT, fileContent); // 文件内容
        values.put(COLUMN_FILE_CREATE_TIME, createTime); // 创建时间
        // 插入数据，返回文件ID（失败返回-1）
        long fileId = db.insert(TABLE_FILES, null, values);
        // 关闭数据库连接
        db.close();
        // 返回插入结果
        return fileId;
    }
    public List<FileInfo> getFilesByUsername(String username) {
        List<FileInfo> fileList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // 查询当前用户的所有文件（按创建时间倒序）
        String sql = "SELECT " + COLUMN_FILE_ID + ", " + COLUMN_FILE_NAME + ", " +
                COLUMN_FILE_USERNAME + ", " + COLUMN_FILE_CREATE_TIME + ", " +
                COLUMN_FILE_CONTENT + " FROM " + TABLE_FILES +
                " WHERE " + COLUMN_FILE_USERNAME + " = ? ORDER BY " + COLUMN_FILE_CREATE_TIME + " DESC";

        Cursor cursor = db.rawQuery(sql, new String[]{username});

        // 遍历游标，封装成FileInfo对象
        if (cursor.moveToFirst()) {
            do {
                long fileId = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_FILE_ID));
                String fileName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FILE_NAME));
                String fileUser = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FILE_USERNAME));
                String createTime = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FILE_CREATE_TIME));
                String fileContent = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FILE_CONTENT));

                // 添加到列表（可选择全参/简参构造）
                fileList.add(new FileInfo(fileId, fileName, fileUser, createTime, fileContent));
            } while (cursor.moveToNext());
        }

        // 关闭游标和数据库
        cursor.close();
        db.close();
        return fileList;
    }
}
