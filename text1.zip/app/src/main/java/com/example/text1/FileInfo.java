package com.example.text1;

// 文件信息实体类（对应files表字段）
public class FileInfo {
    private String fileName;    // 文件名
    private String username;    // 所属用户
    private String createTime;  // 创建时间
    private String fileContent; // 文件内容（可选，若需要展示可添加）
    private long fileId;        // 文件ID（主键，可选）

    // 构造方法（适配查询结果）
    public FileInfo(String fileName, String username, String createTime) {
        this.fileName = fileName;
        this.username = username;
        this.createTime = createTime;
    }

    // 全参构造（可选）
    public FileInfo(long fileId, String fileName, String username, String createTime, String fileContent) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.username = username;
        this.createTime = createTime;
        this.fileContent = fileContent;
    }

    // getter/setter（必须）
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getCreateTime() { return createTime; }
    public void setCreateTime(String createTime) { this.createTime = createTime; }
    public String getFileContent() { return fileContent; }
    public void setFileContent(String fileContent) { this.fileContent = fileContent; }
    public long getFileId() { return fileId; }
    public void setFileId(long fileId) { this.fileId = fileId; }

    public String getOwner() {
        // 直接返回username，作为owner的别名
        return this.username;
    }

    public String getModifyTime() {
        // 直接返回createTime，作为modifyTime的别名
        return this.createTime;
    }
}