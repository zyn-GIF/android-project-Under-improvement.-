package com.example.text1;

public class File {
    private long fileId; // 文件唯一ID（主键自增）
    private String username; // 关联用户表的用户名（外键）
    private String fileName; // 文件名（显示用）
    private String fileContent; // 文件内容（核心数据）
    private String createTime; // 文件创建时间

    // 无参构造
    public File() {}

    // 带参构造（新增文件时使用）
    public File(String username, String fileName, String fileContent, String createTime) {
        this.username = username;
        this.fileName = fileName;
        this.fileContent = fileContent;
        this.createTime = createTime;
    }

    // 所有字段的 getter/setter
    public long getFileId() { return fileId; }
    public void setFileId(long fileId) { this.fileId = fileId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public String getFileContent() { return fileContent; }
    public void setFileContent(String fileContent) { this.fileContent = fileContent; }
    public String getCreateTime() { return createTime; }
    public void setCreateTime(String createTime) { this.createTime = createTime; }
}
