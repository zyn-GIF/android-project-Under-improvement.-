package com.example.text1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class FileContentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_content);

        // 1. 获取从KernelActivity传递的文件数据
        Intent intent = getIntent();
        String fileName = intent.getStringExtra("fileName");
        String username = intent.getStringExtra("username");
        String createTime = intent.getStringExtra("createTime");
        String fileContent = intent.getStringExtra("fileContent");

        // 2. 展示文件信息
        TextView tvName = findViewById(R.id.tv_detail_name);
        TextView tvInfo = findViewById(R.id.tv_detail_info);
        TextView tvContent = findViewById(R.id.tv_detail_content);

        tvName.setText(fileName == null ? "未知文件" : fileName);
        tvInfo.setText((username == null ? "未知用户" : username) + " | " + (createTime == null ? "未知时间" : createTime));
        tvContent.setText(fileContent == null ? "暂无文件内容" : fileContent);

        // 3. 返回按钮点击事件
        findViewById(R.id.btn_back).setOnClickListener(v -> {
            finish(); // 返回上一页（KernelActivity）
        });
    }
}